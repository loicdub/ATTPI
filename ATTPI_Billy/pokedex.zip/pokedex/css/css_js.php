<?php ?>

<link rel = "stylesheet" href = "css/bootstrap.css">
<script src = "js/jquery-1.11.0.min.js"></script>
<script src="js/jquery-migrate-1.2.1.min.js"></script>