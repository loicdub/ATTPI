<?php 
/*
 * Auteur : Nguyen Billy
 * Date : 2018-01-31
 * Titre : Forum
 * Description : Forum PHP
 */
session_start();

session_destroy();

header('Location:index.php');
?>