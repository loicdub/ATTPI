<?php

/*
 * Authors : Dubas Loïc, Pighini Lucas, Nguyen Billy
 * Description : Connection constant
 * Date : 20.02.18
 */

// LOCAL
define('DB_HOST', 'localhost');
define('DB_NAME', 'pokedexdb');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

// MOUETTE
// define('DB_HOST', '10.5.33.20');
// define('DB_PORT', ':3307');
// define('DB_NAME', 'pokedexdb');
// define('DB_USER', 'pokedexAdm');
// define('DB_PASSWORD', 'Super');