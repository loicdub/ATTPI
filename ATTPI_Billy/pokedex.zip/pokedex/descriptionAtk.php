<?php
/*
 * Authors : Dubas Loïc, Pighini Lucas, Nguyen Billy
 * Description : Description of the selected attack
 * Date : 27.02.18
 */
require_once './bdd/mySql.inc.php';
require_once './dao.php';
?>
<!DOCTYPE html><
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
    </body>
</html>
