﻿namespace projet_pre_tpi
{
    partial class frmMain
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblOk = new System.Windows.Forms.Label();
            this.btnNewModel = new System.Windows.Forms.Button();
            this.btnCreateModel = new System.Windows.Forms.Button();
            this.btnLoadModel = new System.Windows.Forms.Button();
            this.pbxYourPinky = new System.Windows.Forms.PictureBox();
            this.pbxYourRing = new System.Windows.Forms.PictureBox();
            this.pbxYourMiddle = new System.Windows.Forms.PictureBox();
            this.pbxYourIndex = new System.Windows.Forms.PictureBox();
            this.pbxYourThumb = new System.Windows.Forms.PictureBox();
            this.pbxPinky = new System.Windows.Forms.PictureBox();
            this.pbxRing = new System.Windows.Forms.PictureBox();
            this.pbxMiddle = new System.Windows.Forms.PictureBox();
            this.pbxIndex = new System.Windows.Forms.PictureBox();
            this.pbxThumb = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYourPinky)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYourRing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYourMiddle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYourIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYourThumb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPinky)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMiddle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxThumb)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Position à recopier :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Votre position : ";
            // 
            // lblOk
            // 
            this.lblOk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOk.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblOk.Location = new System.Drawing.Point(320, 25);
            this.lblOk.Name = "lblOk";
            this.lblOk.Size = new System.Drawing.Size(113, 55);
            this.lblOk.TabIndex = 20;
            this.lblOk.Text = "lblOk";
            this.lblOk.Visible = false;
            // 
            // btnNewModel
            // 
            this.btnNewModel.Location = new System.Drawing.Point(439, 12);
            this.btnNewModel.Name = "btnNewModel";
            this.btnNewModel.Size = new System.Drawing.Size(100, 23);
            this.btnNewModel.TabIndex = 21;
            this.btnNewModel.Text = "Nouveau modèle";
            this.btnNewModel.UseVisualStyleBackColor = true;
            this.btnNewModel.Click += new System.EventHandler(this.btnNewModel_Click);
            // 
            // btnCreateModel
            // 
            this.btnCreateModel.Location = new System.Drawing.Point(439, 41);
            this.btnCreateModel.Name = "btnCreateModel";
            this.btnCreateModel.Size = new System.Drawing.Size(100, 23);
            this.btnCreateModel.TabIndex = 22;
            this.btnCreateModel.Text = "Créer un modèle";
            this.btnCreateModel.UseVisualStyleBackColor = true;
            this.btnCreateModel.Click += new System.EventHandler(this.btnCreateModel_Click);
            // 
            // btnLoadModel
            // 
            this.btnLoadModel.Location = new System.Drawing.Point(439, 70);
            this.btnLoadModel.Name = "btnLoadModel";
            this.btnLoadModel.Size = new System.Drawing.Size(100, 23);
            this.btnLoadModel.TabIndex = 23;
            this.btnLoadModel.Text = "Charger...";
            this.btnLoadModel.UseVisualStyleBackColor = true;
            this.btnLoadModel.Click += new System.EventHandler(this.btnLoadModel_Click);
            // 
            // pbxYourPinky
            // 
            this.pbxYourPinky.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxYourPinky.Location = new System.Drawing.Point(259, 25);
            this.pbxYourPinky.Name = "pbxYourPinky";
            this.pbxYourPinky.Size = new System.Drawing.Size(55, 55);
            this.pbxYourPinky.TabIndex = 14;
            this.pbxYourPinky.TabStop = false;
            // 
            // pbxYourRing
            // 
            this.pbxYourRing.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxYourRing.Location = new System.Drawing.Point(198, 25);
            this.pbxYourRing.Name = "pbxYourRing";
            this.pbxYourRing.Size = new System.Drawing.Size(55, 55);
            this.pbxYourRing.TabIndex = 13;
            this.pbxYourRing.TabStop = false;
            // 
            // pbxYourMiddle
            // 
            this.pbxYourMiddle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxYourMiddle.Location = new System.Drawing.Point(137, 25);
            this.pbxYourMiddle.Name = "pbxYourMiddle";
            this.pbxYourMiddle.Size = new System.Drawing.Size(55, 55);
            this.pbxYourMiddle.TabIndex = 12;
            this.pbxYourMiddle.TabStop = false;
            // 
            // pbxYourIndex
            // 
            this.pbxYourIndex.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxYourIndex.Location = new System.Drawing.Point(76, 25);
            this.pbxYourIndex.Name = "pbxYourIndex";
            this.pbxYourIndex.Size = new System.Drawing.Size(55, 55);
            this.pbxYourIndex.TabIndex = 11;
            this.pbxYourIndex.TabStop = false;
            // 
            // pbxYourThumb
            // 
            this.pbxYourThumb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxYourThumb.Location = new System.Drawing.Point(15, 25);
            this.pbxYourThumb.Name = "pbxYourThumb";
            this.pbxYourThumb.Size = new System.Drawing.Size(55, 55);
            this.pbxYourThumb.TabIndex = 10;
            this.pbxYourThumb.TabStop = false;
            // 
            // pbxPinky
            // 
            this.pbxPinky.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxPinky.Location = new System.Drawing.Point(439, 99);
            this.pbxPinky.Name = "pbxPinky";
            this.pbxPinky.Size = new System.Drawing.Size(100, 100);
            this.pbxPinky.TabIndex = 7;
            this.pbxPinky.TabStop = false;
            // 
            // pbxRing
            // 
            this.pbxRing.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxRing.Location = new System.Drawing.Point(333, 99);
            this.pbxRing.Name = "pbxRing";
            this.pbxRing.Size = new System.Drawing.Size(100, 100);
            this.pbxRing.TabIndex = 6;
            this.pbxRing.TabStop = false;
            // 
            // pbxMiddle
            // 
            this.pbxMiddle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxMiddle.Location = new System.Drawing.Point(227, 99);
            this.pbxMiddle.Name = "pbxMiddle";
            this.pbxMiddle.Size = new System.Drawing.Size(100, 100);
            this.pbxMiddle.TabIndex = 5;
            this.pbxMiddle.TabStop = false;
            // 
            // pbxIndex
            // 
            this.pbxIndex.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxIndex.Location = new System.Drawing.Point(121, 99);
            this.pbxIndex.Name = "pbxIndex";
            this.pbxIndex.Size = new System.Drawing.Size(100, 100);
            this.pbxIndex.TabIndex = 4;
            this.pbxIndex.TabStop = false;
            // 
            // pbxThumb
            // 
            this.pbxThumb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxThumb.Location = new System.Drawing.Point(15, 99);
            this.pbxThumb.Name = "pbxThumb";
            this.pbxThumb.Size = new System.Drawing.Size(100, 100);
            this.pbxThumb.TabIndex = 3;
            this.pbxThumb.TabStop = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 211);
            this.Controls.Add(this.btnLoadModel);
            this.Controls.Add(this.btnCreateModel);
            this.Controls.Add(this.btnNewModel);
            this.Controls.Add(this.lblOk);
            this.Controls.Add(this.pbxYourPinky);
            this.Controls.Add(this.pbxYourRing);
            this.Controls.Add(this.pbxYourMiddle);
            this.Controls.Add(this.pbxYourIndex);
            this.Controls.Add(this.pbxYourThumb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbxPinky);
            this.Controls.Add(this.pbxRing);
            this.Controls.Add(this.pbxMiddle);
            this.Controls.Add(this.pbxIndex);
            this.Controls.Add(this.pbxThumb);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "Projet pre-TPI";
            ((System.ComponentModel.ISupportInitialize)(this.pbxYourPinky)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYourRing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYourMiddle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYourIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYourThumb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPinky)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMiddle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxThumb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pbxThumb;
        private System.Windows.Forms.PictureBox pbxIndex;
        private System.Windows.Forms.PictureBox pbxMiddle;
        private System.Windows.Forms.PictureBox pbxRing;
        private System.Windows.Forms.PictureBox pbxPinky;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbxYourThumb;
        private System.Windows.Forms.PictureBox pbxYourIndex;
        private System.Windows.Forms.PictureBox pbxYourRing;
        private System.Windows.Forms.PictureBox pbxYourMiddle;
        private System.Windows.Forms.PictureBox pbxYourPinky;
        private System.Windows.Forms.Label lblOk;
        private System.Windows.Forms.Button btnNewModel;
        private System.Windows.Forms.Button btnCreateModel;
        private System.Windows.Forms.Button btnLoadModel;
    }
}

